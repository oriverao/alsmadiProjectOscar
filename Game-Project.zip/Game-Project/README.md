# 2D Java Game Framework

A collection of classes used for 2d game programming in Java. Much of the dirty work is taken care which makes this useful for beginner game programmers. 

## Installation

1. install the java JDK7.
2. clone this repo.
3. run make.bat if on windows, make.sh if on linux, or compile it with netbeans.
4. add the .jar file created to your project.

## Usage

After building the framework, add the .jar file to your project. Once added to your project have your class extend "game.framework.Game" and implement all the methods from the abstract class. Once everything is set up correctly just run the project and you should see a blank window with a blue background. (Better instructions to come later! :p)
