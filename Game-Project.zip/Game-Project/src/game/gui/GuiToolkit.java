package game.gui;

import java.util.LinkedList;

public class GuiToolkit 
{
    public static final LinkedList<GuiActions> callQueue = new LinkedList<>();
}
