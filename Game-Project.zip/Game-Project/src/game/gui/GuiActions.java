package game.gui;

public interface GuiActions {
}
