package game.gui;

public enum MenuState 
{
    OPEN,
    CLOSED
}
